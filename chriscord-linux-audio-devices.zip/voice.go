package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"math"
	"net"
	"net/url"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/gordonklaus/portaudio"
	"github.com/gorilla/websocket"
	"github.com/hraban/opus"
	"github.com/pion/interceptor"
	"github.com/pion/webrtc/v3"
	"github.com/pion/webrtc/v3/pkg/media"
	wailsruntime "github.com/wailsapp/wails/v2/pkg/runtime"
)

const (
	voiceSampleRate = 48000
	voiceChannels   = 1
	voiceFrameMs    = 20
	voiceFrameSize  = voiceSampleRate * voiceFrameMs / 1000 // 960 samples per 20ms frame
)

// voiceRemoteSource is the decode state for one other participant's
// incoming audio track — a small buffer of decoded PCM the mixer drains
// from, filled by that track's own read/decode goroutine.
type voiceRemoteSource struct {
	username string // whose audio this is — for per-user volume/mute ("screen:<name>" for a stream's sound)
	stereo   bool   // a screen share's sound (buf is interleaved L/R); voices are mono
	decoder  *opus.Decoder
	mu       sync.Mutex
	buf      []int16
	// A voice sent in stereo (a music bot, say — people's microphones are
	// mono): buf holds the middle of the sound, (L+R)/2, so smoothing and
	// skipping work on it as on any voice, and side the difference,
	// (L-R)/2, sample for sample beside it; whatever's taken off the front
	// of buf is taken off side too (keepSide). nil for a mono voice.
	side []int16

	// Stream sound only (avsync.go): whose share it is, and the capture
	// time (sharer's clock, ms) of the first sample still in buf.
	sharer   string
	headCap  float64
	unwrap   tsUnwrap
	frac     float64   // position between samples when playing faster/slower
	delay    float64   // how far behind capture the sound plays (ms), see syncRate
	offSince time.Time // when the wanted delay started differing from delay
	heardLag float64   // what the delay actually is right now (reported to the page)
	// How soon after capture the sound arrives here (the least seen over
	// the last few seconds), same clock terms as the delays.
	arrHave       bool
	arrMin        float64
	arrWinMin     float64
	arrWinStarted time.Time

	// Packet order, and smoothing over breaks in the sound.
	seqHave bool
	lastSeq uint16
	fadeIn  bool // the next samples played start a fresh run: fade them in

	// Voices only: since when more than voiceQueueHigh has stayed queued
	// (zero while it hasn't), and the last skip ahead — see trimVoiceQueue,
	// used when smooth playback (po, playout.go) is turned off.
	highSince time.Time
	lastSkip  time.Time
	po        playout

	// What happened over the last few seconds, for the log (logStats).
	stAt                                     time.Time
	stPkts, stLost, stLate                   int
	stUnder, stJumps, stHeld, stFast, stSlow int
}

// VoiceSession owns everything for one active voice-channel connection. A
// fresh one is created on every join AND on every roster-change refresh
// (the previous one is closed first) — see the matching design note in
// the server's voice.rs for why that's deliberate: it's what makes the
// "simple" version able to evolve into seamless renegotiation later
// without a rewrite, since the actual capture/encode/decode/mix pipeline
// here doesn't care how many times a negotiation happens over its life.
type VoiceSession struct {
	ctx          context.Context
	app          *App // back-reference so the capture loop can signal speaking state to the server
	boardID      string
	micName      string
	speakerName  string
	pc           *webrtc.PeerConnection
	localTrack   *webrtc.TrackLocalStaticSample
	videoTrack   *webrtc.TrackLocalStaticSample // this app's camera, see video.go
	screenOut    *rtpOut                        // this app's screen share (screen.go), sent with capture timestamps (avsync.go)
	soundOut     *rtpOut                        // its sound
	screenLowOut *rtpOut                        // its smaller version, when someone asks for one (screen_low.go)
	encoder      *opus.Encoder

	captureStream *portaudio.Stream
	captureBuf    []int16
	vad           *voiceActivity // only touched from within the capture goroutine — no mutex needed
	noise         micCleaner     // noise suppression (noise.go), same goroutine
	// Points at the App's own voiceMuted flag, not an owned value — a
	// roster-change refresh tears down and rebuilds this whole session,
	// and muting shouldn't silently reset just because someone else
	// joined or left in the background. See App.voiceMuted.
	muted *atomic.Bool
	// Same reasoning and pattern as muted above — points at App.voiceDeafened.
	deafened *atomic.Bool

	playStream *portaudio.Stream
	playBuf    []int16
	sfx        sfxQueue // the app's own sounds, mixed into the call's output (sfx.go)

	remotesMu sync.Mutex
	remotes   map[string]*voiceRemoteSource // keyed by remote track ID

	closeOnce sync.Once
	stopped   chan struct{}

	// A different microphone or speaker chosen in Settings during the call
	// (SetVoiceDevices): picked up by the capture / playback loop, which
	// opens it and closes the old one on its own thread.
	swapMic, swapSpeaker chan string
	namesMu              sync.Mutex // guards micName, speakerName after start

	// Trickle-ICE ordering. Candidates start flowing both ways the moment
	// each side calls SetLocalDescription — before the other side has the
	// description they belong to. The server drops a candidate that
	// arrives before this client's offer (it has no connection for it
	// yet), and pion rejects one added before the server's answer has
	// been applied ("remote description not set"). Either way the
	// candidate is lost and ICE has to find the path the slow way
	// (peer-reflexive discovery, retransmits) — the multi-second wait
	// before audio. So both directions are held here until it's safe.
	iceMu      sync.Mutex
	offerSent  bool                      // our offer is on the wire: local candidates can go straight out
	pendingOut []webrtc.ICECandidateInit // local candidates gathered before the offer was sent
	remoteSet  bool                      // the server's answer is applied: remote candidates can be added
	pendingIn  []webrtc.ICECandidateInit // server candidates that arrived before its answer
}

// findDeviceByName does a case-insensitive substring match against
// PortAudio's own device list — needed because the browser-side Web Audio
// API (used to populate Settings > Voice) and PortAudio have entirely
// separate device identifiers; matching by the human-readable name is the
// practical bridge between them. Falls back to the default device for
// that direction if no match is found or name is empty.
func findDeviceByName(name string, wantInput bool) (*portaudio.DeviceInfo, error) {
	logAudioDevices()
	d, err := pickDevice(name, wantInput)
	if err == nil && d != nil && runtime.GOOS == "linux" {
		dir := "output"
		if wantInput {
			dir = "input"
		}
		log.Printf("audio: %s %q (asked for %q)", dir, d.Name, name)
	}
	return d, err
}

func pickDevice(name string, wantInput bool) (*portaudio.DeviceInfo, error) {
	// Chosen in Settings on Linux (audiodevices.go): a sound server device
	// opens through the sound server's own ALSA device (aimed at it by
	// openAudioStream); a PortAudio device by its exact name.
	if strings.HasPrefix(name, "sys:") {
		if d := soundServerDevice(wantInput); d != nil {
			return d, nil
		}
		name = ""
	} else if pa, ok := strings.CutPrefix(name, "pa:"); ok {
		if devices, err := portaudio.Devices(); err == nil {
			for _, d := range devices {
				if d.Name == pa && ((wantInput && d.MaxInputChannels > 0) || (!wantInput && d.MaxOutputChannels > 0)) {
					return d, nil
				}
			}
		}
		name = "" // gone (unplugged?): the default
	}
	if name != "" {
		devices, err := portaudio.Devices()
		if err == nil {
			lower := strings.ToLower(name)
			for _, d := range devices {
				if wantInput && d.MaxInputChannels < 1 {
					continue
				}
				if !wantInput && d.MaxOutputChannels < 1 {
					continue
				}
				if strings.Contains(strings.ToLower(d.Name), lower) || strings.Contains(lower, strings.ToLower(d.Name)) {
					return d, nil
				}
			}
		}
	}
	// Linux: ALSA's "default" is often the sound card itself, which the
	// desktop's sound server (PipeWire or PulseAudio) already has open — so
	// it fails ("unable to open slave") or falls through to the wrong
	// device. The sound server's own ALSA device, when there is one, is
	// what the rest of the desktop uses: prefer it.
	if d := soundServerDevice(wantInput); d != nil {
		return d, nil
	}
	if wantInput {
		return portaudio.DefaultInputDevice()
	}
	d, err := portaudio.DefaultOutputDevice()
	if a := analogOutput(d); a != nil {
		return a, nil
	}
	return d, err
}

// analogOutput: without a sound server's device, PortAudio's "default"
// output on Linux can be the first card it finds — often a graphics chip's
// HDMI sound, with nothing plugged in, so calls are silent. If def is an
// HDMI/DisplayPort output and the computer has a built-in (analog) one,
// that's returned instead; nil otherwise.
func analogOutput(def *portaudio.DeviceInfo) *portaudio.DeviceInfo {
	if runtime.GOOS != "linux" || def == nil {
		return nil
	}
	digital := func(n string) bool {
		n = strings.ToLower(n)
		return strings.Contains(n, "hdmi") || strings.Contains(n, "displayport")
	}
	if !digital(def.Name) {
		return nil
	}
	devices, err := portaudio.Devices()
	if err != nil {
		return nil
	}
	for _, d := range devices {
		if d.MaxOutputChannels > 0 && !digital(d.Name) && strings.Contains(strings.ToLower(d.Name), "analog") {
			return d
		}
	}
	return nil
}

// soundServerDevice: Linux's "pipewire" or "pulse" ALSA device (in that
// order) if PortAudio lists it; nil elsewhere or if there's neither.
func soundServerDevice(wantInput bool) *portaudio.DeviceInfo {
	if runtime.GOOS != "linux" {
		return nil
	}
	devices, err := portaudio.Devices()
	if err != nil {
		return nil
	}
	for _, want := range []string{"pipewire", "pulse"} {
		for _, d := range devices {
			if !strings.EqualFold(d.Name, want) {
				continue
			}
			if (wantInput && d.MaxInputChannels > 0) || (!wantInput && d.MaxOutputChannels > 0) {
				return d
			}
		}
	}
	return nil
}

// logAudioDevices writes PortAudio's devices to the log once (Linux), to
// tell which one a call opened when sound goes missing.
var logAudioDevicesOnce sync.Once

func logAudioDevices() {
	if runtime.GOOS != "linux" {
		return
	}
	logAudioDevicesOnce.Do(func() {
		devices, err := portaudio.Devices()
		if err != nil {
			log.Printf("audio: couldn't list devices: %v", err)
			return
		}
		var names []string
		for _, d := range devices {
			names = append(names, fmt.Sprintf("%q (in %d, out %d)", d.Name, d.MaxInputChannels, d.MaxOutputChannels))
		}
		log.Printf("audio: devices: %s", strings.Join(names, ", "))
	})
}

// JoinVoiceChannel connects presence to a voice board AND establishes the
// real WebRTC audio connection: capturing from micName and playing back on
// speakerName, both the device labels shown in Settings > Voice (not the
// browser's deviceId — see findDeviceByName for why). Returns once the
// offer has been sent, not once the call is fully connected; the frontend
// should treat "connected" as a separate, later state signaled over the
// existing voice:state mechanism plus connection-state events emitted
// below.
func (a *App) JoinVoiceChannel(boardID, micName, speakerName string, knownOthers []string) error {
	a.writeMu.Lock()
	conn := a.ws
	a.writeMu.Unlock()
	if conn == nil {
		return fmt.Errorf("not connected")
	}

	log.Printf("voice: JoinVoiceChannel called for board %s (explicit user join, known others: %v)", boardID, knownOthers)

	// join_voice has to reach the server, and be fully processed, before
	// the offer below — it's what registers this participant in the
	// server's own voice presence map, which is exactly what
	// renegotiate_one reads to figure out who else is in the room and
	// needs adding to everyone else's existing connections. Sending the
	// offer first (as this used to) meant that renegotiation could run
	// before the server had any record this participant existed at all,
	// silently renegotiating nothing — this participant's own audio would
	// still reach whoever they explicitly requested via knownOthers, but
	// nobody who was already in the call before them would ever hear it.
	a.writeMu.Lock()
	// Says whether we're muted/deafened as we join, so the server (and
	// everyone else) starts from the real state, never a stale one.
	msg, _ := json.Marshal(map[string]interface{}{"type": "join_voice", "board_id": boardID,
		"muted": a.voiceMuted.Load(), "deafened": a.voiceDeafened.Load()})
	err := a.ws.WriteMessage(websocket.TextMessage, msg)
	a.writeMu.Unlock()
	if err != nil {
		return fmt.Errorf("failed to send join_voice: %w", err)
	}

	if err := a.startVoiceSession(boardID, micName, speakerName, knownOthers, "initial join"); err != nil {
		return fmt.Errorf("failed to start voice session: %w", err)
	}
	return nil
}

// ReconnectVoice rebuilds this call's connection to the server in place —
// for when it failed (the page calls this on "failed"). Same channel, same
// devices, mute/deafen untouched; the server treats the fresh offer as a
// refresh, so everyone else's connections aren't disturbed, and a camera or
// screen share that's running carries straight on into the new connection.
func (a *App) ReconnectVoice(knownOthers []string) error {
	a.voiceMu.Lock()
	session := a.voice
	a.voiceMu.Unlock()
	if session == nil {
		return fmt.Errorf("not in a call")
	}
	session.namesMu.Lock()
	mic, speaker := session.micName, session.speakerName
	session.namesMu.Unlock()
	return a.startVoiceSession(session.boardID, mic, speaker, knownOthers, "connection failed, reconnecting")
}

func (a *App) LeaveVoiceChannel() error {
	a.stopVoiceSession()
	a.e2ee.end()
	// Muted or deafened stays as you set it, for the next call.

	a.writeMu.Lock()
	defer a.writeMu.Unlock()
	if a.ws == nil {
		return fmt.Errorf("not connected")
	}
	msg, _ := json.Marshal(map[string]string{"type": "leave_voice"})
	return a.ws.WriteMessage(websocket.TextMessage, msg)
}

// sendSpeaking tells the server this participant's local speaking state
// changed, for it to rebroadcast to everyone else — so a speaking
// indicator can show up next to their avatar server-wide, not just
// locally to themselves. Best-effort: silently does nothing if not
// currently connected, same as any other send during a voice session
// that might be in the middle of a reconnect.
func (a *App) sendSpeaking(boardID string, speaking bool) {
	a.writeMu.Lock()
	defer a.writeMu.Unlock()
	if a.ws == nil {
		return
	}
	msg, _ := json.Marshal(map[string]interface{}{"type": "speaking", "board_id": boardID, "speaking": speaking})
	if err := a.ws.WriteMessage(websocket.TextMessage, msg); err != nil {
		log.Printf("voice: failed to send speaking=%v: %v", speaking, err)
	}
}

// sendVoiceMuteState tells the server this participant's mute/deafen
// state changed, for it to rebroadcast to everyone else — so a mute or
// deafen icon can show up next to their name. Best-effort, same as
// sendSpeaking above.
func (a *App) sendVoiceMuteState(boardID string, muted, deafened bool) {
	a.writeMu.Lock()
	defer a.writeMu.Unlock()
	if a.ws == nil {
		return
	}
	msg, _ := json.Marshal(map[string]interface{}{
		"type": "voice_mute_state", "board_id": boardID, "muted": muted, "deafened": deafened,
	})
	_ = a.ws.WriteMessage(websocket.TextMessage, msg)
}

// ToggleMute flips whether this participant's microphone audio is being
// transmitted during the current voice session, and returns the new
// muted state. Purely client-side — muting simply stops sending anything
// at all, so the server and other participants never need to know or be
// told; there's nothing to forward when nothing gets sent. The flag lives on
// the App, not the session, so it survives a roster-change refresh
// tearing down and rebuilding the underlying connection.
//
// Outside a call it still works (the button is always in your row, as on
// Discord): it's how you'll join the next call — join_voice says so.
func (a *App) ToggleMute() bool {
	a.voiceMu.Lock()
	session := a.voice
	a.voiceMu.Unlock()
	newState := !a.voiceMuted.Load()
	a.voiceMuted.Store(newState)
	if session != nil {
		a.sendVoiceMuteState(session.boardID, newState, a.voiceDeafened.Load())
	}
	return newState
}

// IsMuted reports the current mute state, for the UI to sync against
// (e.g. on startup or after a reconnect) without toggling it.
func (a *App) IsMuted() bool {
	return a.voiceMuted.Load()
}

// ToggleDeafen flips whether the other people's voices are being played,
// and returns the new deafened state. Streams being watched keep their
// sound (they have their own volume and mute). Deafening also mutes, and
// undeafening also unmutes — a clean, symmetric toggle rather than
// leaving mute as a separate thing to manage after undeafening. Purely
// client-side, same as mute: deafened audio is still received and
// decoded as normal, just not written to the output device, so nothing
// needs telling the server or other participants. Outside a call it sets
// how you'll join the next one, as ToggleMute does.
func (a *App) ToggleDeafen() bool {
	a.voiceMu.Lock()
	session := a.voice
	a.voiceMu.Unlock()
	newState := !a.voiceDeafened.Load()
	a.voiceDeafened.Store(newState)
	a.voiceMuted.Store(newState)
	if session != nil {
		a.sendVoiceMuteState(session.boardID, newState, newState)
	}
	return newState
}

// IsDeafened reports the current deafen state, for the UI to sync
// against without toggling it.
func (a *App) IsDeafened() bool {
	return a.voiceDeafened.Load()
}

// startVoiceSession tears down any existing session (this IS the "refresh"
// path — a roster-change re-join is handled identically to a first-time
// join, see startup.go/wsReader's voice:state handling) and builds a fresh
// one: opens mic capture, creates the PeerConnection, wires local and
// remote track handling, and sends the initial offer. knownOthers is the
// currently-known roster of the channel (excluding self) — the offer
// declares one receive-only placeholder transceiver per entry, in this
// exact order, so the server has somewhere valid to attach each
// participant's audio without needing to add media sections the offer
// never asked for. Always declares at least one placeholder even with no
// known others, to avoid a known pion/webrtc-rs bug where a single-media-
// section offer's on_track callback never fires at all.
func (a *App) startVoiceSession(boardID, micName, speakerName string, knownOthers []string, reason string) error {
	log.Printf("voice: startVoiceSession(board=%s, reason=%q, knownOthers=%v) — tearing down any existing session and sending a fresh offer", boardID, reason, knownOthers)
	a.stopVoiceSession()

	encoder, err := opus.NewEncoder(voiceSampleRate, voiceChannels, opus.AppVoIP)
	if err != nil {
		return fmt.Errorf("opus encoder: %w", err)
	}

	localTrack, err := webrtc.NewTrackLocalStaticSample(
		webrtc.RTPCodecCapability{MimeType: webrtc.MimeTypeOpus, ClockRate: voiceSampleRate, Channels: voiceChannels},
		"audio", "chriscord-mic",
	)
	if err != nil {
		return fmt.Errorf("local track: %w", err)
	}

	pc, err := newVoicePeerConnection(webrtc.Configuration{
		ICEServers: []webrtc.ICEServer{{URLs: []string{"stun:stun.l.google.com:19302"}}},
	})
	if err != nil {
		return fmt.Errorf("peer connection: %w", err)
	}
	if _, err := pc.AddTrack(localTrack); err != nil {
		pc.Close()
		return fmt.Errorf("add local track: %w", err)
	}

	// One receive-only placeholder per known other, always at least one —
	// see the function comment above for why even the solo case needs
	// this. expected_others (sent with the offer below) is what tells the
	// server which placeholder, by position, belongs to which username.
	placeholderCount := len(knownOthers)
	if placeholderCount < 1 {
		placeholderCount = 1
	}
	for i := 0; i < placeholderCount; i++ {
		if _, err := pc.AddTransceiverFromKind(webrtc.RTPCodecTypeAudio, webrtc.RTPTransceiverInit{
			Direction: webrtc.RTPTransceiverDirectionRecvonly,
		}); err != nil {
			log.Printf("voice: failed to add placeholder transceiver %d: %v", i, err)
		}
	}

	session := &VoiceSession{
		ctx:         a.ctx,
		app:         a,
		boardID:     boardID,
		micName:     micName,
		speakerName: speakerName,
		pc:          pc,
		localTrack:  localTrack,
		encoder:     encoder,
		remotes:     make(map[string]*voiceRemoteSource),
		stopped:     make(chan struct{}),
		swapMic:     make(chan string, 1),
		swapSpeaker: make(chan string, 1),
		muted:       &a.voiceMuted,
		deafened:    &a.voiceDeafened,
	}

	// The camera's send-only section — last, after every audio section
	// (the server maps the audio ones by position). See video.go.
	session.addVideoSender()

	pc.OnICECandidate(func(c *webrtc.ICECandidate) {
		if c == nil {
			return
		}
		init := c.ToJSON()
		session.iceMu.Lock()
		if !session.offerSent {
			// The server has no connection to put this on yet: hold it
			// until the offer has gone (sent right after it, below).
			session.pendingOut = append(session.pendingOut, init)
			session.iceMu.Unlock()
			return
		}
		session.iceMu.Unlock()
		a.sendVoiceCandidate(boardID, init)
	})

	pc.OnConnectionStateChange(func(s webrtc.PeerConnectionState) {
		log.Printf("voice: connection %s", s)
		wailsruntime.EventsEmit(a.ctx, "voice:connectionState", s.String())
	})
	pc.OnICEConnectionStateChange(func(s webrtc.ICEConnectionState) {
		log.Printf("voice: ICE %s", s)
	})

	pc.OnTrack(func(track *webrtc.TrackRemote, receiver *webrtc.RTPReceiver) {
		log.Printf("voice: OnTrack fired, track id=%s kind=%s", track.ID(), track.Kind())
		if track.Kind() == webrtc.RTPCodecTypeVideo {
			session.handleRemoteVideo(track)
			return
		}
		session.handleRemoteTrack(track)
	})

	offer, err := pc.CreateOffer(nil)
	if err != nil {
		pc.Close()
		return fmt.Errorf("create offer: %w", err)
	}
	if err := pc.SetLocalDescription(offer); err != nil {
		pc.Close()
		return fmt.Errorf("set local description: %w", err)
	}

	a.voiceMu.Lock()
	a.voice = session
	a.voiceMu.Unlock()
	a.presenceChanged() // "in a call" is part of your status (which device's shows)

	// The offer goes out first, so ICE and DTLS get going on the server
	// while the sound devices open — opening them can take a second or
	// more (PortAudio enumerating devices, WASAPI starting up — slower
	// still in a virtual machine), and used to hold the offer back.
	a.writeMu.Lock()
	if a.ws == nil {
		a.writeMu.Unlock()
		return fmt.Errorf("not connected")
	}
	msg, _ := json.Marshal(map[string]interface{}{
		"type": "voice_offer", "board_id": boardID, "sdp": offer.SDP, "expected_others": knownOthers,
	})
	err = a.ws.WriteMessage(websocket.TextMessage, msg)
	a.writeMu.Unlock()
	if err != nil {
		return err
	}
	log.Printf("voice: offer sent")
	// Hello to everyone in the call, for the keys (e2ee.go) — after
	// join_voice and the offer, so the server has us in the channel.
	a.e2ee.begin(boardID)

	// Now the candidates gathered meanwhile (sent after the offer on the
	// same socket, so the server always has the connection for them).
	session.iceMu.Lock()
	session.offerSent = true
	held := session.pendingOut
	session.pendingOut = nil
	session.iceMu.Unlock()
	for _, c := range held {
		a.sendVoiceCandidate(boardID, c)
	}

	if err := session.startCapture(micName); err != nil {
		wailsruntime.EventsEmit(a.ctx, "voice:error", fmt.Sprintf("microphone: %v", err))
	}
	if err := session.startPlayback(speakerName); err != nil {
		wailsruntime.EventsEmit(a.ctx, "voice:error", fmt.Sprintf("speaker: %v", err))
	}
	return nil
}

// sendVoiceCandidate sends one of this client's ICE candidates to the server.
func (a *App) sendVoiceCandidate(boardID string, init webrtc.ICECandidateInit) {
	a.writeMu.Lock()
	defer a.writeMu.Unlock()
	if a.ws == nil {
		return
	}
	msg, _ := json.Marshal(map[string]interface{}{
		"type": "voice_ice", "board_id": boardID,
		"candidate": init.Candidate, "sdp_mid": init.SDPMid, "sdp_mline_index": init.SDPMLineIndex,
	})
	a.ws.WriteMessage(websocket.TextMessage, msg)
}

func (a *App) stopVoiceSession() {
	a.voiceMu.Lock()
	session := a.voice
	a.voice = nil
	a.voiceMu.Unlock()
	if session != nil {
		session.close()
		a.presenceChanged()
	}
}

// handleVoiceAnswer applies the SDP answer the server sent back for the
// current session's offer. Called from wsReader on a "voice_answer"
// message.
func (a *App) handleVoiceAnswer(sdp string) {
	a.voiceMu.Lock()
	session := a.voice
	a.voiceMu.Unlock()
	if session == nil {
		return
	}
	answer := webrtc.SessionDescription{Type: webrtc.SDPTypeAnswer, SDP: sdp}
	if err := session.pc.SetRemoteDescription(answer); err != nil {
		wailsruntime.EventsEmit(a.ctx, "voice:error", fmt.Sprintf("failed to apply answer: %v", err))
		return
	}
	// The server's candidates that got here before its answer did (it
	// starts sending them as soon as it has made the answer).
	session.iceMu.Lock()
	session.remoteSet = true
	held := session.pendingIn
	session.pendingIn = nil
	session.iceMu.Unlock()
	if len(held) > 0 {
		log.Printf("voice: answer applied; adding %d server candidate(s) that arrived before it", len(held))
	}
	for _, c := range held {
		a.addVoiceCandidate(session, c)
	}
}

// handleVoiceICE applies an ICE candidate the server sent for the current
// session. Called from wsReader on a "voice_ice" message.
func (a *App) handleVoiceICE(candidate, sdpMid string, sdpMLineIndex *uint16) {
	a.voiceMu.Lock()
	session := a.voice
	a.voiceMu.Unlock()
	if session == nil {
		return
	}
	init := webrtc.ICECandidateInit{Candidate: candidate}
	if sdpMid != "" {
		init.SDPMid = &sdpMid
	}
	if sdpMLineIndex != nil {
		init.SDPMLineIndex = sdpMLineIndex
	}
	session.iceMu.Lock()
	if !session.remoteSet {
		// pion refuses candidates before the remote description is set:
		// keep it for when the answer arrives (handleVoiceAnswer).
		session.pendingIn = append(session.pendingIn, init)
		session.iceMu.Unlock()
		return
	}
	session.iceMu.Unlock()
	a.addVoiceCandidate(session, init)
}

// addVoiceCandidate adds one of the server's ICE candidates to the session
// (once its answer is applied), plus a copy at the address this client
// reaches the server at.
func (a *App) addVoiceCandidate(session *VoiceSession, init webrtc.ICECandidateInit) {
	candidate := init.Candidate
	if err := session.pc.AddICECandidate(init); err != nil {
		log.Printf("voice: could not add server candidate %q: %v", candidate, err)
	}

	// The server is behind the same router as its LAN, so the address it
	// advertises is usually a private one (192.168.x.x) that nobody outside
	// that LAN can reach. The address this client already reaches the
	// server at — the domain/IP it was added with — is the one that works
	// from here, so offer ICE a copy of the candidate at that address too.
	// ICE tries both and keeps whichever connects: on the server's own LAN
	// that's still the LAN address (it's ranked higher); from anywhere else
	// it's the public one, via the router's UDP port-forward.
	go func() {
		copyCand := a.serverAddressCopy(candidate)
		if copyCand == "" {
			return
		}
		a.voiceMu.Lock()
		current := a.voice
		a.voiceMu.Unlock()
		if current != session {
			return // call ended or was replaced while resolving
		}
		copyInit := init
		copyInit.Candidate = copyCand
		if err := session.pc.AddICECandidate(copyInit); err != nil {
			log.Printf("voice: could not add server-address candidate: %v", err)
			return
		}
		log.Printf("voice: also trying the server at %s", strings.Fields(copyCand)[4])
	}()
}

// serverAddressCopy returns a copy of one of the server's ICE candidates
// with its private host address replaced by the IPv4 address this client
// connects to the server at (the saved server domain, resolved via DNS) —
// or "" if that doesn't apply: not a private IPv4 host candidate, the
// domain doesn't resolve to IPv4, or it resolves to a private/LAN address
// itself (then the original candidate already covers it).
func (a *App) serverAddressCopy(candidate string) string {
	// candidate:<foundation> <component> <transport> <priority> <address> <port> typ <type> ...
	parts := strings.Fields(candidate)
	if len(parts) < 8 || parts[6] != "typ" || parts[7] != "host" || !strings.EqualFold(parts[2], "udp") {
		return ""
	}
	lanIP := net.ParseIP(parts[4])
	if lanIP == nil || lanIP.To4() == nil || !lanIP.IsPrivate() {
		return ""
	}
	a.mu.Lock()
	domain := a.domain
	a.mu.Unlock()
	u, err := url.Parse(normaliseHTTP(domain))
	if err != nil || u.Hostname() == "" {
		return ""
	}
	var serverIP net.IP
	if ip := net.ParseIP(u.Hostname()); ip != nil {
		serverIP = ip.To4()
	} else if ips, err := net.LookupIP(u.Hostname()); err == nil {
		for _, ip := range ips {
			if v4 := ip.To4(); v4 != nil {
				serverIP = v4
				break
			}
		}
	}
	if serverIP == nil || serverIP.IsPrivate() || serverIP.IsLoopback() || serverIP.Equal(lanIP) {
		return ""
	}
	priority, err := strconv.ParseUint(parts[3], 10, 32)
	if err != nil {
		return ""
	}
	parts[0] += "d"
	if priority > 2 {
		parts[3] = strconv.FormatUint(priority-2, 10)
	}
	parts[4] = serverIP.String()
	return strings.Join(parts, " ")
}

// handleVoiceRenegotiate applies a server-initiated renegotiation to the
// CURRENT, already-established PeerConnection — this is the seamless
// mid-call update mechanism: when someone else joins the channel after
// this session already exists, the server adds a transceiver to this
// exact connection and sends a fresh offer for it, rather than this
// client tearing anything down and re-joining from scratch. Nothing about
// the existing capture/playback streams, mute/deafen state, or already-
// flowing audio to/from anyone else is touched — only the underlying
// PeerConnection negotiates a new media section and answers it.
func (a *App) handleVoiceRenegotiate(sdp string) {
	a.voiceMu.Lock()
	session := a.voice
	a.voiceMu.Unlock()
	if session == nil {
		log.Printf("voice: got a renegotiate offer but no active session")
		return
	}
	offer := webrtc.SessionDescription{Type: webrtc.SDPTypeOffer, SDP: sdp}
	if err := session.pc.SetRemoteDescription(offer); err != nil {
		log.Printf("voice: renegotiate SetRemoteDescription failed: %v", err)
		return
	}
	answer, err := session.pc.CreateAnswer(nil)
	if err != nil {
		log.Printf("voice: renegotiate CreateAnswer failed: %v", err)
		return
	}
	if err := session.pc.SetLocalDescription(answer); err != nil {
		log.Printf("voice: renegotiate SetLocalDescription failed: %v", err)
		return
	}
	a.writeMu.Lock()
	defer a.writeMu.Unlock()
	if a.ws == nil {
		log.Printf("voice: renegotiate answer ready but not connected, dropping")
		return
	}
	msg, _ := json.Marshal(map[string]string{
		"type": "voice_renegotiate_answer", "board_id": session.boardID, "sdp": answer.SDP,
	})
	if err := a.ws.WriteMessage(websocket.TextMessage, msg); err != nil {
		log.Printf("voice: failed to send renegotiate answer: %v", err)
	} else {
		log.Printf("voice: renegotiate answer sent successfully")
	}
}

func (s *VoiceSession) startCapture(micName string) error {
	device, err := findDeviceByName(micName, true)
	if err != nil {
		return fmt.Errorf("no microphone available: %w", err)
	}

	started := make(chan error, 1)
	go func() {
		// PortAudio's Windows backend (WASAPI) appears to require a
		// stream's entire lifecycle — open, start, read, stop, close —
		// to happen on the same OS thread; Go's scheduler is otherwise
		// free to migrate a goroutine between OS threads between calls,
		// which caused a real, reproducible access violation when open/
		// start ran on one thread and the read loop ran on another.
		// Locking this goroutine to one thread for the whole duration,
		// including the final Stop/Close, avoids that entirely.
		runtime.LockOSThread()
		defer runtime.UnlockOSThread()

		s.captureBuf = make([]int16, voiceFrameSize)
		s.vad = newVoiceActivity()
		params := portaudio.StreamParameters{
			Input: portaudio.StreamDeviceParameters{
				Device:   device,
				Channels: voiceChannels,
				Latency:  device.DefaultLowInputLatency,
			},
			SampleRate:      voiceSampleRate,
			FramesPerBuffer: voiceFrameSize,
		}
		stream, err := openAudioStream(micName, true, params, s.captureBuf)
		if err != nil {
			started <- fmt.Errorf("open capture stream: %w", err)
			return
		}
		if err := stream.Start(); err != nil {
			stream.Close()
			started <- fmt.Errorf("start capture stream: %w", err)
			return
		}
		s.captureStream = stream
		started <- nil
		defer s.noise.close()

		encoded := make([]byte, 4000)
		for {
			select {
			case <-s.stopped:
				stream.Stop()
				stream.Close()
				if s.vad.reset() {
					wailsruntime.EventsEmit(s.ctx, "voice:speaking", false)
					s.app.sendSpeaking(s.boardID, false)
				}
				return
			case name := <-s.swapMic:
				if ns, err := s.openCapture(name); err != nil {
					log.Printf("voice: couldn't switch microphone to %q: %v", name, err)
				} else {
					stream.Stop()
					stream.Close()
					stream = ns
					s.captureStream = ns
					s.namesMu.Lock()
					s.micName = name
					s.namesMu.Unlock()
				}
			default:
			}
			if err := stream.Read(); err != nil {
				return
			}
			if s.muted.Load() {
				// Still draining the stream above to keep it healthy, but
				// nothing gets encoded or sent while muted — this is a
				// real "not transmitting" mute, not just silence sent
				// over the wire. Also clear the local speaking indicator
				// if it was on, since it would be misleading to show
				// "speaking" while muted.
				if s.vad.reset() {
					wailsruntime.EventsEmit(s.ctx, "voice:speaking", false)
					s.app.sendSpeaking(s.boardID, false)
				}
				continue
			}
			// Background noise out first (when it's on), so the volume and
			// the speaking detection below only hear your voice.
			s.noise.process(s.captureBuf)
			// Input gain + input sensitivity: the speaking ring and what's
			// actually transmitted follow the same decision, so the ring
			// lighting up means others really are hearing you. Below the
			// threshold, silence is sent instead (keeps the stream's timing
			// steady rather than stopping and starting it).
			open, changed, level, threshold := s.vad.process(s.captureBuf)
			s.vad.emitLevel(s.app, level, threshold)
			if changed {
				wailsruntime.EventsEmit(s.ctx, "voice:speaking", open)
				s.app.sendSpeaking(s.boardID, open)
			}
			if !open {
				clear(s.captureBuf)
			}
			n, err := s.encoder.Encode(s.captureBuf, encoded)
			if err != nil {
				continue
			}
			// Encrypted end to end (e2ee.go); the server only forwards it.
			sealed := s.app.e2ee.seal(kindAudio, encoded[:n])
			if sealed == nil {
				continue
			}
			_ = s.localTrack.WriteSample(media.Sample{Data: sealed, Duration: voiceFrameMs * 1e6})
		}
	}()
	return <-started
}

// rmsLevel is a frame's root-mean-square amplitude (int16 scale); see
// levelDB in audio.go for the dBFS version the sensitivity setting uses.
func rmsLevel(samples []int16) float64 {
	if len(samples) == 0 {
		return 0
	}
	var sum float64
	for _, v := range samples {
		f := float64(v)
		sum += f * f
	}
	return math.Sqrt(sum / float64(len(samples)))
}

func (s *VoiceSession) startPlayback(speakerName string) error {
	device, err := findDeviceByName(speakerName, false)
	if err != nil {
		return fmt.Errorf("no speaker available: %w", err)
	}

	started := make(chan error, 1)
	go func() {
		// Same reasoning as startCapture above — the whole stream
		// lifecycle stays on one locked OS thread.
		runtime.LockOSThread()
		defer runtime.UnlockOSThread()

		// Stereo out (a shared screen's sound is stereo; voices go to both
		// sides), unless the device only has one channel.
		outCh := 2
		if device.MaxOutputChannels < 2 {
			outCh = 1
		}
		s.playBuf = make([]int16, voiceFrameSize*outCh)
		params := portaudio.StreamParameters{
			Output: portaudio.StreamDeviceParameters{
				Device:   device,
				Channels: outCh,
				Latency:  device.DefaultLowOutputLatency,
			},
			SampleRate:      voiceSampleRate,
			FramesPerBuffer: voiceFrameSize,
		}
		stream, err := openAudioStream(speakerName, false, params, s.playBuf)
		if err != nil {
			started <- fmt.Errorf("open playback stream: %w", err)
			return
		}
		if err := stream.Start(); err != nil {
			stream.Close()
			started <- fmt.Errorf("start playback stream: %w", err)
			return
		}
		s.playStream = stream
		// How long after being written a sample is actually heard.
		outLatencyMs := 20.0
		if info := stream.Info(); info != nil && info.OutputLatency > 0 {
			outLatencyMs = float64(info.OutputLatency) / float64(time.Millisecond)
		}
		started <- nil
		streamOut := make([]float64, voiceFrameSize*2)
		lagTick := 0

		for {
			select {
			case <-s.stopped:
				stream.Stop()
				stream.Close()
				return
			case name := <-s.swapSpeaker:
				if ns, ch, buf, err := s.openPlayback(name); err != nil {
					log.Printf("voice: couldn't switch speaker to %q: %v", name, err)
				} else {
					stream.Stop()
					stream.Close()
					stream, outCh = ns, ch
					s.playBuf = buf
					s.playStream = ns
					if info := ns.Info(); info != nil && info.OutputLatency > 0 {
						outLatencyMs = float64(info.OutputLatency) / float64(time.Millisecond)
					}
					s.namesMu.Lock()
					s.speakerName = name
					s.namesMu.Unlock()
				}
			default:
			}
			for i := range s.playBuf {
				s.playBuf[i] = 0
			}
			deafened := s.deafened.Load()
			s.remotesMu.Lock()
			for _, r := range s.remotes {
				r.mu.Lock()
				g := audioCfg.playbackGain(r.username)
				if r.stereo {
					// A stream's sound: read a little faster or slower than
					// real time to stay in step with the picture (avsync.go).
					n := r.readStretched(streamOut, outLatencyMs)
					if lagTick%25 == 0 && r.heardLag > 0 {
						// The page shows the picture this far behind capture
						// too, so it lines up with what's being heard.
						wailsruntime.EventsEmit(s.ctx, "stream:audiolag", map[string]interface{}{"user": r.sharer, "ms": r.heardLag})
					}
					// Not silenced by deafening: deafen is for the call's
					// voices; a stream you're watching keeps its sound (its
					// own volume/mute is on the stream).
					if g > 0 {
						for i := 0; i < n; i++ {
							l, rr := streamOut[2*i]*g, streamOut[2*i+1]*g
							if outCh == 2 {
								mixInto(&s.playBuf[2*i], l)
								mixInto(&s.playBuf[2*i+1], rr)
							} else {
								mixInto(&s.playBuf[i], (l+rr)/2)
							}
						}
					}
					r.mu.Unlock()
					continue
				}
				// Smooth playback (playout.go): trims built-up delay out of
				// pauses, and waits for a little to queue after running dry.
				if voiceSmoothing.Load() {
					before := len(r.buf)
					play, fade := r.po.next(&r.buf)
					r.keepSide(before)
					if fade {
						r.fadeIn = true
					}
					if !play {
						r.mu.Unlock()
						continue
					}
				}
				n := len(r.buf)
				if n > voiceFrameSize {
					n = voiceFrameSize
				}
				// After a skip or a cut, fade the first 5 ms in.
				fade := 0
				if r.fadeIn && n > 0 {
					fade, r.fadeIn = 240, false
				}
				// Per-user volume/mute (set from the right-click menu)
				// times overall output volume; 0 means skip them.
				if !deafened && g > 0 {
					for i := 0; i < n; i++ {
						v := float64(r.buf[i]) * g
						d := 0.0 // a stereo voice: left is v+d, right v-d
						if r.side != nil && i < len(r.side) {
							d = float64(r.side[i]) * g
						}
						if i < fade {
							f := float64(i) / float64(fade)
							v, d = v*f, d*f
						}
						if outCh == 2 {
							mixInto(&s.playBuf[2*i], v+d)
							mixInto(&s.playBuf[2*i+1], v-d)
						} else {
							mixInto(&s.playBuf[i], v)
						}
					}
				}
				r.buf = r.buf[n:]
				if r.side != nil {
					r.side = r.side[min(n, len(r.side)):]
				}
				r.mu.Unlock()
			}
			s.remotesMu.Unlock()
			// The app's own sounds (Linux: sfx.go) — heard even when
			// deafened, as a mute or leave sound should be.
			s.sfx.mixInto(s.playBuf, outCh)
			lagTick++
			if err := stream.Write(); err != nil {
				return
			}
			// Kept briefly while sharing sound, so it can be taken back out
			// if it turns up in the share (echo.go).
			echoRef.push(s.playBuf, outCh)
		}
	}()
	return <-started
}

// handleRemoteTrack reads and decodes one other participant's incoming
// audio track for as long as it lasts, feeding decoded PCM into that
// track's own buffer for the playback loop above to mix in.
func (s *VoiceSession) handleRemoteTrack(track *webrtc.TrackRemote) {
	// The server labels each forwarded voice "audio-<username>", and a
	// screen share's sound "screenaudio-<username>" (stereo; its volume is
	// set separately, under "screen:<username>").
	channels := voiceChannels
	name := strings.TrimPrefix(track.ID(), "audio-")
	stereo := strings.HasPrefix(track.ID(), "screenaudio-")
	if stereo {
		channels, name = 2, "screen:"+strings.TrimPrefix(track.ID(), "screenaudio-")
	}
	decoder, err := opus.NewDecoder(voiceSampleRate, channels)
	if err != nil {
		return
	}
	source := &voiceRemoteSource{username: name, decoder: decoder, stereo: stereo, sharer: strings.TrimPrefix(name, "screen:"), fadeIn: true, po: newPlayout(name)}
	// Keyed per track (a new share by the same person arrives as a new one).
	key := fmt.Sprintf("%s#%d", track.ID(), track.SSRC())
	s.remotesMu.Lock()
	s.remotes[key] = source
	s.remotesMu.Unlock()
	defer func() {
		s.remotesMu.Lock()
		delete(s.remotes, key)
		s.remotesMu.Unlock()
	}()

	pcm := make([]int16, 5760*2) // room for the longest Opus packet (120 ms), in stereo
	// A voice's decoder is mono until its packets turn out to be stereo
	// (the flag in each Opus packet's first byte): then stereo from there on.
	voiceStereo := false
	for {
		select {
		case <-s.stopped:
			return
		default:
		}
		packet, _, err := track.ReadRTP()
		if err != nil {
			return
		}
		{
			// Packets that arrive after a later one are dropped (appended
			// out of order they'd crackle, and add delay), and a few
			// missing ones are filled in by Opus' loss concealment rather
			// than leaving a click-shaped hole. Voices and stream sound alike.
			source.mu.Lock()
			source.stPkts++
			lost := 0
			if source.seqHave {
				d := int16(packet.SequenceNumber - source.lastSeq)
				switch {
				case d <= 0 && d > -100: // a little behind: late, or a duplicate
					source.stLate++
					source.mu.Unlock()
					continue
				case d <= 0 || d > 100:
					// Far off either way: the sender started a new stream
					// (they reconnected — the server forwards their packets
					// unrenumbered). Carry on from here, nothing lost.
				default:
					lost = int(d) - 1
				}
			}
			source.seqHave, source.lastSeq = true, packet.SequenceNumber
			source.stLost += lost
			source.mu.Unlock()
			if lost > 0 && lost <= 5 {
				plc := make([]int16, voiceFrameSize*channels)
				for i := 0; i < lost; i++ {
					if decoder.DecodePLC(plc) == nil {
						source.mu.Lock()
						source.add(plc, voiceStereo)
						source.mu.Unlock()
					}
				}
			}
		}
		// Decrypt (e2ee.go). A frame that doesn't open — no key from them
		// yet, or not encrypted at all — is treated like a lost packet.
		payload, ok := s.app.e2ee.open(source.sharer, kindAudio, packet.Payload)
		if !ok {
			continue
		}
		if !stereo && !voiceStereo && len(payload) > 0 && payload[0]&0x04 != 0 {
			// This voice is in stereo (a music bot): decode it so, from here.
			if d, err := opus.NewDecoder(voiceSampleRate, 2); err == nil {
				decoder, channels, voiceStereo = d, 2, true
				source.mu.Lock()
				source.decoder = d
				source.side = make([]int16, len(source.buf), len(source.buf)+voiceFrameSize*4)
				source.mu.Unlock()
				log.Printf("voice: %s is sending stereo — playing it in stereo", source.username)
			}
		}
		n, err := decoder.Decode(payload, pcm)
		if err != nil {
			continue
		}
		source.mu.Lock()
		if stereo {
			// Where this packet sits on the sharer's clock; if it doesn't
			// follow on from what's queued (a gap, a new share), the queue's
			// timeline restarts from it.
			capMs := source.unwrap.ms(packet.Timestamp, 48000)
			source.noteArrival(nowWallMs() - capMs)
			queued := float64(len(source.buf)/2) / 48
			if len(source.buf) == 0 || math.Abs(source.headCap+queued-capMs) > 60 {
				source.headCap = capMs - queued
			}
		}
		if stereo {
			source.buf = append(source.buf, pcm[:n*channels]...)
		} else {
			source.add(pcm[:n*channels], voiceStereo)
		}
		if !stereo && !voiceSmoothing.Load() {
			before := len(source.buf)
			source.trimVoiceQueue() // smoothing's off: the plain skip-ahead
			source.keepSide(before)
		}
		source.mu.Unlock()
	}
}

// How much of someone's voice may wait to be played (samples at 48 kHz,
// mono). Packets normally arrive about as fast as they're played, so only
// a frame or two is queued. After the network stalls, though, everything
// held up arrives in one burst — and, played at normal speed, that backlog
// would stay as delay for the rest of the call (it used to: seconds of lag
// until the connection was rebuilt). So a backlog is skipped.
const (
	voiceQueueTarget = 48 * 60  // kept after catching up: 60 ms
	voiceQueueHigh   = 48 * 120 // more than this for 2 s straight: catch up
	voiceQueueMax    = 48 * 250 // more than this: catch up straight away
)

// add queues a voice's decoded sound (call with r.mu held): mono as it
// is, stereo (interleaved) split into its middle (buf) and difference (side).
func (r *voiceRemoteSource) add(pcm []int16, stereo bool) {
	if !stereo {
		r.buf = append(r.buf, pcm...)
		if r.side != nil { // was stereo: no difference
			r.side = append(r.side, make([]int16, len(pcm))...)
		}
		return
	}
	for i := 0; i+1 < len(pcm); i += 2 {
		l, rr := int32(pcm[i]), int32(pcm[i+1])
		r.buf = append(r.buf, int16((l+rr)/2))
		r.side = append(r.side, int16((l-rr)/2))
	}
}

// keepSide: buf was before samples long and has had some taken off its
// front (smoothing, a skip): side loses the same ones.
func (r *voiceRemoteSource) keepSide(before int) {
	if r.side == nil {
		return
	}
	if gone := before - len(r.buf); gone > 0 {
		r.side = r.side[min(gone, len(r.side)):]
	}
}

// trimVoiceQueue drops the oldest queued sound when too much has built up
// (call with r.mu held, after adding to it). The next sound played is
// faded in, so the skip doesn't click.
func (r *voiceRemoteSource) trimVoiceQueue() {
	n := len(r.buf)
	switch {
	case n > voiceQueueMax:
	case n > voiceQueueHigh:
		if r.highSince.IsZero() {
			r.highSince = time.Now()
			return
		}
		if time.Since(r.highSince) < 2*time.Second {
			return
		}
	default:
		r.highSince = time.Time{}
		return
	}
	drop := n - voiceQueueTarget
	r.buf = r.buf[drop:]
	r.highSince = time.Time{}
	r.fadeIn = true
	// A burst skips again with each packet that lands: one line per hiccup.
	if time.Since(r.lastSkip) > 5*time.Second {
		log.Printf("voice: %s's sound was %d ms behind (a network hiccup) — skipped ahead", r.username, n/48)
	}
	r.lastSkip = time.Now()
}

func (s *VoiceSession) close() {
	s.closeOnce.Do(func() {
		close(s.stopped)
		// captureStream and playStream are stopped and closed by their
		// own goroutines above, on whichever OS thread each was opened
		// and started on — not here. Touching them from this different
		// goroutine is exactly the cross-thread access pattern that
		// caused a real crash; the streams' own loops notice s.stopped
		// closing and clean themselves up on their own locked thread.
		if s.pc != nil {
			s.pc.Close()
		}
	})
}

// ── MIC TEST ─────────────────────────────────────────────────────
// A pure local loopback — captured audio gets written straight back out
// to the selected speaker, with no encoding, no network, and no server
// involved at all. Exists purely so device selection and the whole local
// capture/playback pipeline can be verified on their own, separately from
// whether a call actually connects.
type micTestSession struct {
	captureStream *portaudio.Stream
	playStream    *portaudio.Stream
	stopped       chan struct{}
	closeOnce     sync.Once

	// Only set when starting this test auto-deafened an active call, to
	// isolate the test's own loopback audio from live call audio playing
	// at the same time. Remembers the exact pre-test state so StopMicTest
	// restores it precisely — including leaving someone who was already
	// deafened before the test untouched — rather than assuming
	// "undeafened and unmuted" is always the right end state.
	autoDeafened    bool
	preTestMuted    bool
	preTestDeafened bool
}

var (
	micTestMu   sync.Mutex
	micTestSess *micTestSession
)

// openCapture opens and starts the microphone chosen as name, recording
// into the session's capture buffer (for switching during a call; on the
// capture goroutine's thread).
func (s *VoiceSession) openCapture(name string) (*portaudio.Stream, error) {
	device, err := findDeviceByName(name, true)
	if err != nil {
		return nil, err
	}
	stream, err := openAudioStream(name, true, portaudio.StreamParameters{
		Input:           portaudio.StreamDeviceParameters{Device: device, Channels: voiceChannels, Latency: device.DefaultLowInputLatency},
		SampleRate:      voiceSampleRate,
		FramesPerBuffer: voiceFrameSize,
	}, s.captureBuf)
	if err != nil {
		return nil, err
	}
	if err := stream.Start(); err != nil {
		stream.Close()
		return nil, err
	}
	return stream, nil
}

// openPlayback opens and starts the speaker chosen as name, with its own
// buffer (its channel count may differ from the old one's).
func (s *VoiceSession) openPlayback(name string) (*portaudio.Stream, int, []int16, error) {
	device, err := findDeviceByName(name, false)
	if err != nil {
		return nil, 0, nil, err
	}
	ch := 2
	if device.MaxOutputChannels < 2 {
		ch = 1
	}
	buf := make([]int16, voiceFrameSize*ch)
	stream, err := openAudioStream(name, false, portaudio.StreamParameters{
		Output:          portaudio.StreamDeviceParameters{Device: device, Channels: ch, Latency: device.DefaultLowOutputLatency},
		SampleRate:      voiceSampleRate,
		FramesPerBuffer: voiceFrameSize,
	}, buf)
	if err != nil {
		return nil, 0, nil, err
	}
	if err := stream.Start(); err != nil {
		stream.Close()
		return nil, 0, nil, err
	}
	return stream, ch, buf, nil
}

// SetVoiceDevices moves the call you're in (if any) to the microphone and
// speaker chosen in Settings, without leaving it. Names as for
// JoinVoiceChannel.
func (a *App) SetVoiceDevices(micName, speakerName string) {
	a.voiceMu.Lock()
	s := a.voice
	a.voiceMu.Unlock()
	if s == nil {
		return
	}
	s.namesMu.Lock()
	micChanged, spkChanged := micName != s.micName, speakerName != s.speakerName
	s.namesMu.Unlock()
	send := func(ch chan string, v string) {
		select { // only the latest choice matters
		case <-ch:
		default:
		}
		select {
		case ch <- v:
		default:
		}
	}
	if micChanged && s.captureStream != nil {
		send(s.swapMic, micName)
	}
	if spkChanged && s.playStream != nil {
		send(s.swapSpeaker, speakerName)
	}
}

func (a *App) StartMicTest(micName, speakerName string) error {
	micTestMu.Lock()
	if micTestSess != nil {
		micTestMu.Unlock()
		return fmt.Errorf("mic test already running")
	}
	micTestMu.Unlock()

	inDevice, err := findDeviceByName(micName, true)
	if err != nil {
		return fmt.Errorf("no microphone available: %w", err)
	}
	outDevice, err := findDeviceByName(speakerName, false)
	if err != nil {
		return fmt.Errorf("no speaker available: %w", err)
	}

	// If a voice call is active, isolate the test's own loopback audio
	// from it by deafening for the duration — otherwise live call audio
	// and the test's mic-to-speaker loopback would play simultaneously
	// and be hard to tell apart. Only auto-deafen if not already
	// deafened, and remember the exact pre-test state either way so
	// StopMicTest can restore it precisely.
	var autoDeafened, preTestMuted, preTestDeafened bool
	a.voiceMu.Lock()
	inCall := a.voice != nil
	a.voiceMu.Unlock()
	if inCall {
		preTestMuted = a.voiceMuted.Load()
		preTestDeafened = a.voiceDeafened.Load()
		if !preTestDeafened {
			autoDeafened = true
			a.voiceDeafened.Store(true)
			a.voiceMuted.Store(true)
		}
	}

	started := make(chan error, 1)
	// If setup fails partway through below, the auto-deafen above already
	// applied but no session object will exist for StopMicTest to revert
	// it from — this covers that so a failed test never leaves an active
	// call stuck deafened.
	revertAutoDeafen := func() {
		if autoDeafened {
			a.voiceDeafened.Store(preTestDeafened)
			a.voiceMuted.Store(preTestMuted)
		}
	}
	go func() {
		// Same reasoning as VoiceSession's capture/playback above — the
		// whole lifecycle of both streams stays on one locked OS thread.
		runtime.LockOSThread()
		defer runtime.UnlockOSThread()

		captureBuf := make([]int16, voiceFrameSize)
		// Stereo out, as in a call (startPlayback): many sound cards opened
		// directly can't play one channel.
		outCh := 2
		if outDevice.MaxOutputChannels < 2 {
			outCh = 1
		}
		playBuf := make([]int16, voiceFrameSize*outCh)
		vad := newVoiceActivity()
		var noise micCleaner
		defer noise.close()

		inParams := portaudio.StreamParameters{
			Input:           portaudio.StreamDeviceParameters{Device: inDevice, Channels: voiceChannels, Latency: inDevice.DefaultLowInputLatency},
			SampleRate:      voiceSampleRate,
			FramesPerBuffer: voiceFrameSize,
		}
		inStream, err := openAudioStream(micName, true, inParams, captureBuf)
		if err != nil {
			revertAutoDeafen()
			started <- fmt.Errorf("open microphone: %w", err)
			return
		}
		outParams := portaudio.StreamParameters{
			Output:          portaudio.StreamDeviceParameters{Device: outDevice, Channels: outCh, Latency: outDevice.DefaultLowOutputLatency},
			SampleRate:      voiceSampleRate,
			FramesPerBuffer: voiceFrameSize,
		}
		outStream, err := openAudioStream(speakerName, false, outParams, playBuf)
		if err != nil {
			inStream.Close()
			revertAutoDeafen()
			started <- fmt.Errorf("open speaker: %w", err)
			return
		}
		if err := inStream.Start(); err != nil {
			inStream.Close()
			outStream.Close()
			revertAutoDeafen()
			started <- fmt.Errorf("start microphone: %w", err)
			return
		}
		if err := outStream.Start(); err != nil {
			inStream.Stop()
			inStream.Close()
			outStream.Close()
			revertAutoDeafen()
			started <- fmt.Errorf("start speaker: %w", err)
			return
		}

		sess := &micTestSession{
			captureStream: inStream, playStream: outStream, stopped: make(chan struct{}),
			autoDeafened: autoDeafened, preTestMuted: preTestMuted, preTestDeafened: preTestDeafened,
		}
		micTestMu.Lock()
		micTestSess = sess
		micTestMu.Unlock()
		started <- nil

		for {
			select {
			case <-sess.stopped:
				inStream.Stop()
				inStream.Close()
				outStream.Stop()
				outStream.Close()
				return
			default:
			}
			if err := inStream.Read(); err != nil {
				return
			}
			// Same noise suppression, gain and sensitivity as a real call,
			// so the test sounds like what others would hear (silence while
			// you're below it).
			noise.process(captureBuf)
			open, _, level, threshold := vad.process(captureBuf)
			vad.emitLevel(a, level, threshold)
			if !open {
				clear(captureBuf)
			}
			for i, v := range captureBuf {
				for c := 0; c < outCh; c++ {
					playBuf[i*outCh+c] = v
				}
			}
			if err := outStream.Write(); err != nil {
				return
			}
		}
	}()
	err = <-started
	if err != nil {
		log.Printf("audio: voice test couldn't start: %v", err)
	}
	return err
}

func (a *App) StopMicTest() {
	micTestMu.Lock()
	sess := micTestSess
	micTestSess = nil
	micTestMu.Unlock()
	if sess != nil {
		sess.closeOnce.Do(func() { close(sess.stopped) })
		if sess.autoDeafened {
			a.voiceDeafened.Store(sess.preTestDeafened)
			a.voiceMuted.Store(sess.preTestMuted)
		}
	}
}

// mixInto adds v to one output sample, clipping instead of wrapping.
func mixInto(dst *int16, v float64) {
	sum := float64(*dst) + v
	if sum > 32767 {
		sum = 32767
	} else if sum < -32768 {
		sum = -32768
	}
	*dst = int16(sum)
}

// newVoicePeerConnection is webrtc.NewPeerConnection (same codecs and
// interceptors) with quicker ICE timeouts: a connection that stops working
// is reported "failed" after about 10 s instead of 30, so the page can
// rebuild it (ReconnectVoice) before anyone's left talking to nobody.
func newVoicePeerConnection(cfg webrtc.Configuration) (*webrtc.PeerConnection, error) {
	m := &webrtc.MediaEngine{}
	if err := m.RegisterDefaultCodecs(); err != nil {
		return nil, err
	}
	reg := &interceptor.Registry{}
	if err := webrtc.RegisterDefaultInterceptors(m, reg); err != nil {
		return nil, err
	}
	var se webrtc.SettingEngine
	se.SetICETimeouts(4*time.Second, 6*time.Second, 2*time.Second) // disconnected, failed, keepalive
	api := webrtc.NewAPI(webrtc.WithMediaEngine(m), webrtc.WithInterceptorRegistry(reg), webrtc.WithSettingEngine(se))
	return api.NewPeerConnection(cfg)
}

// syncRate decides how fast to play a stream's queued sound (call with
// r.mu held). The sound is the master clock: it plays steadily at a fixed
// delay behind capture, and the page times the picture to it (dropping
// frames that miss their moment) — see avsync.go. The delay is chosen to
// leave the picture enough time to arrive and decode (from the page's
// measurements, SetStreamVideoLag), and only changes when that settles
// somewhere clearly different for a few seconds — never chasing one slow
// frame. Changes, and the slow drift between two computers' sound clocks,
// are absorbed by playing up to 3% faster or slower for a moment.
func (r *voiceRemoteSource) syncRate(outLatencyMs float64) (rate float64, hold bool) {
	trim := func(max int) {
		if len(r.buf) > max {
			drop := len(r.buf) - max
			drop -= drop % 2
			r.buf = r.buf[drop:]
			r.headCap += float64(drop/2) / 48
		}
	}
	trim(48000 * 2 * 2) // never more than 2 s queued

	// The delay to aim for. All of these are "this computer's clock minus
	// the sharer's capture time", so they include the (unknown) difference
	// between the two clocks — which is fine, as long as everything is
	// compared in those same terms.
	if !r.arrHave {
		return 1, false // nothing has arrived yet
	}
	// The sound itself: when it arrives, plus a cushion for network jitter,
	// plus the sound card's own delay (heard, below, includes it too —
	// leaving it out here kept the sound permanently "late", always
	// hurrying, and running the queue dry).
	want := r.arrMin + 100 + outLatencyMs
	if vl, ok := streamVideoLag(r.sharer); ok {
		want = math.Max(want, vl+20) // late enough for the picture to keep up
	}
	want = math.Min(want, r.arrMin+1000) // but never more than a second behind
	now := time.Now()
	switch {
	case r.delay == 0, math.Abs(want-r.delay) > 1500: // first figure, or a whole new timeline
		r.delay, r.offSince = want, time.Time{}
	case math.Abs(want-r.delay) > 60:
		if r.offSince.IsZero() {
			r.offSince = now
		} else if now.Sub(r.offSince) > 3*time.Second {
			r.delay, r.offSince = want, time.Time{}
		}
	default:
		r.offSince = time.Time{}
	}
	if len(r.buf) == 0 {
		return 1, false
	}
	// How old what's played now will be when it's heard, against the aim.
	heard := nowWallMs() - r.headCap + outLatencyMs
	r.heardLag = heard
	diff := heard - r.delay
	if diff > 0 && len(r.buf)/2 < 48*40 {
		// Running late, but the queue is nearly empty already: hurrying
		// would only make it run dry. Let the delay settle instead.
		return 1, false
	}
	switch {
	case diff > 400: // far behind (a long hiccup): jump to where it should be
		drop := int(diff*48) * 2
		if drop > len(r.buf) {
			drop = len(r.buf)
		}
		drop -= drop % 2
		r.buf = r.buf[drop:]
		r.headCap += float64(drop/2) / 48
		r.heardLag = r.delay
		r.stJumps++
		r.fadeIn = true
		return 1, false
	case diff < -150: // far ahead (just started): wait until it's due
		r.stHeld++
		r.fadeIn = true
		return 1, true
	case diff > 120: // well off: catch up at 2.5% (just audible, briefly)
		r.stFast++
		return 1.025, false
	case diff < -120:
		r.stSlow++
		return 0.975, false
	case diff > 15: // a little off: ease back at up to 1% (not audible)
		r.stFast++
		return 1 + math.Min(diff, 100)/10000, false
	case diff < -15:
		r.stSlow++
		return 1 + math.Max(diff, -100)/10000, false
	}
	return 1, false
}

// readStretched fills out (interleaved stereo, one 20 ms output frame)
// from r.buf at the rate syncRate picks, interpolating between samples,
// and returns how many frames it wrote (fewer if it ran short).
func (r *voiceRemoteSource) readStretched(out []float64, outLatencyMs float64) int {
	r.logStats()
	rate, hold := r.syncRate(outLatencyMs)
	if hold {
		return 0
	}
	avail := len(r.buf) / 2
	pos := r.frac
	n := 0
	for n < voiceFrameSize {
		i := int(pos)
		if i+1 >= avail {
			break
		}
		t := pos - float64(i)
		out[2*n] = float64(r.buf[2*i])*(1-t) + float64(r.buf[2*i+2])*t
		out[2*n+1] = float64(r.buf[2*i+1])*(1-t) + float64(r.buf[2*i+3])*t
		n++
		pos += rate
	}
	used := int(pos)
	if used > avail {
		used = avail
	}
	r.buf = r.buf[used*2:]
	r.frac = pos - float64(used)
	if r.frac < 0 {
		r.frac = 0
	}
	r.headCap += float64(used) / 48
	// Smooth the edges of every break so they don't click: fade in after
	// a pause or a jump, fade out when the queue runs dry mid-frame.
	if r.fadeIn && n > 0 {
		k := min(n, 96)
		for i := 0; i < k; i++ {
			g := float64(i) / float64(k)
			out[2*i] *= g
			out[2*i+1] *= g
		}
		r.fadeIn = false
	}
	if n < voiceFrameSize {
		r.stUnder++
		k := min(n, 96)
		for i := 0; i < k; i++ {
			g := float64(i) / float64(k)
			out[2*(n-1-i)] *= g
			out[2*(n-1-i)+1] *= g
		}
		r.fadeIn = true
	}
	return n
}

// logStats writes a line about this stream's sound every 5 seconds, so
// crackles can be traced: packets lost or out of order on the way, the
// queue running dry, or the timing corrections. Call with r.mu held.
func (r *voiceRemoteSource) logStats() {
	if r.stAt.IsZero() {
		r.stAt = time.Now()
		return
	}
	if time.Since(r.stAt) < 5*time.Second {
		return
	}
	queued := float64(len(r.buf)/2) / 48
	log.Printf("stream sound from %s — last 5 s: %d packets, %d lost (filled in), %d out of order, %d run-dry, %d jumps, %d frames held, %d faster / %d slower; delay %.0f ms over arrival, heard %.0f ms over arrival, %.0f ms queued",
		r.sharer, r.stPkts, r.stLost, r.stLate, r.stUnder, r.stJumps, r.stHeld, r.stFast, r.stSlow, r.delay-r.arrMin, r.heardLag-r.arrMin, queued)
	r.stAt = time.Now()
	r.stPkts, r.stLost, r.stLate, r.stUnder, r.stJumps, r.stHeld, r.stFast, r.stSlow = 0, 0, 0, 0, 0, 0, 0, 0
}

// noteArrival tracks how soon after capture this stream's sound arrives:
// the smallest figure over 5-second windows (the network's best case;
// jitter only ever adds to it). Call with r.mu held.
func (r *voiceRemoteSource) noteArrival(lag float64) {
	now := time.Now()
	if !r.arrHave {
		r.arrHave, r.arrMin, r.arrWinMin, r.arrWinStarted = true, lag, lag, now
		return
	}
	if lag < r.arrWinMin {
		r.arrWinMin = lag
	}
	if lag < r.arrMin {
		r.arrMin = lag
	}
	if now.Sub(r.arrWinStarted) > 5*time.Second {
		r.arrMin, r.arrWinMin, r.arrWinStarted = r.arrWinMin, lag, now
	}
}
